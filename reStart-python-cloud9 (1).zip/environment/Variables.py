Variable: int = 1

#print(Variable,type(Variable) )

Variable = "Andres"

#print(Variable,type(Variable) )

Variable = True

print(Variable,type(Variable) )

